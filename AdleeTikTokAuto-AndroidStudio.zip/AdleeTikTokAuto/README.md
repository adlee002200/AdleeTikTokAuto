# Adlee TikTok Auto

Projek Android Studio (Kotlin) untuk:
- Auto-scroll TikTok apabila TikTok berada di hadapan.
- Auto-tap butang tuntut yang jelas dibaca oleh Android Accessibility (Shop/LIVE).
- Tetapan sela scroll 2–15 saat.

## Batasan penting
- Projek ini bukan APK siap pasang. Persekitaran pembinaan ini tidak mempunyai Android SDK/Gradle, jadi APK tidak dapat dikompilasi atau diuji di sini.
- Build melalui Android Studio: buka folder projek, tunggu Gradle Sync, kemudian pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.
- Pada telefon, aktifkan Accessibility untuk Adlee TikTok Auto dan benarkan akses.
- TikTok mesti terbuka di skrin, skrin telefon mesti hidup. Tiada jaminan semua kempen/reward boleh dituntut kerana UI dan syarat TikTok berubah.
- Aplikasi hanya cuba klik butang claim/tuntut yang jelas. Ia tidak membeli barang, memasukkan pembayaran, memintas CAPTCHA, atau mengakses akaun/kata laluan.

## Cara build di Android Studio
1. Ekstrak ZIP ini.
2. Buka Android Studio > **Open** > pilih folder `AdleeTikTokAuto`.
3. Tunggu Gradle Sync selesai.
4. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Ambil fail `app-debug.apk` daripada `app/build/outputs/apk/debug/` dan pindahkan ke telefon.

Jika mahu build melalui GitHub Actions, muat naik folder projek ke repository GitHub, kemudian buka tab **Actions** dan jalankan workflow **Build Android APK**. APK akan disediakan sebagai artifact apabila workflow berjaya.

## Sasaran
- Package: `com.adlee.tiktokauto`
- Minimum Android: 8.0 (API 26)
- Target SDK: 35
