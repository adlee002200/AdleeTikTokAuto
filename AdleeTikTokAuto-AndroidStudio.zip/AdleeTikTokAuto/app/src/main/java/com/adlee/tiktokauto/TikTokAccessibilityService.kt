package com.adlee.tiktokauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class TikTokAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastScrollAt = 0L
    private var lastClaimAt = 0L

    private val loop = object : Runnable {
        override fun run() {
            runAutomation()
            handler.postDelayed(this, 900L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.removeCallbacks(loop)
        handler.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // The timed loop handles content changes; no event text is stored or transmitted.
    }

    override fun onInterrupt() = Unit

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }

    private fun runAutomation() {
        val settings = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val autoScroll = settings.getBoolean(MainActivity.KEY_SCROLL, true)
        val autoClaim = settings.getBoolean(MainActivity.KEY_CLAIM, false)
        if (!autoScroll && !autoClaim) return

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != MainActivity.TIKTOK_PACKAGE) return

        val now = SystemClock.elapsedRealtime()
        if (autoClaim && now - lastClaimAt >= 1800L) {
            if (findAndClickClaim(root)) {
                lastClaimAt = now
                return // avoid scrolling immediately after tapping a claim button
            }
        }

        if (autoScroll) {
            val intervalSeconds = settings.getInt(MainActivity.KEY_INTERVAL, 5).coerceIn(2, 15)
            if (now - lastScrollAt >= intervalSeconds * 1000L) {
                swipeToNextVideo()
                lastScrollAt = now
            }
        }
    }

    private fun findAndClickClaim(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 350) {
            val node = queue.removeFirst()
            visited++
            val label = listOfNotNull(node.text?.toString(), node.contentDescription?.toString())
                .joinToString(" ").trim().lowercase(Locale.ROOT)

            if (isClaimLabel(label)) {
                var target: AccessibilityNodeInfo? = node
                var depth = 0
                while (target != null && depth < 5) {
                    if (target.isClickable && target.isEnabled) {
                        if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    }
                    target = target.parent
                    depth++
                }
            }

            for (index in 0 until node.childCount) {
                node.getChild(index)?.let(queue::add)
            }
        }
        return false
    }

    private fun isClaimLabel(label: String): Boolean {
        if (label.isBlank()) return false
        if (listOf("terms", "rules", "learn more", "syarat", "terma").any { label.contains(it) }) return false
        return label == "claim" || label == "collect" || label == "tuntut" || label == "tebus" ||
            label == "ambil" || label == "claim voucher" || label == "claim reward" ||
            label == "collect reward" || label == "ambil ganjaran" || label == "ambil hadiah" ||
            label.startsWith("claim ") || label.startsWith("tuntut ") || label.startsWith("tebus ")
    }

    private fun swipeToNextVideo() {
        val width = resources.displayMetrics.widthPixels.toFloat()
        val height = resources.displayMetrics.heightPixels.toFloat()
        val path = Path().apply {
            moveTo(width * 0.52f, height * 0.78f)
            lineTo(width * 0.52f, height * 0.30f)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 320L))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
