package com.adlee.tiktokauto

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private lateinit var scrollSwitch: Switch
    private lateinit var claimSwitch: Switch
    private lateinit var intervalText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(26), dp(22), dp(24))
            setBackgroundColor(0xFF101014.toInt())
        }
        val scroller = ScrollView(this).apply { addView(page) }

        page.addView(TextView(this).apply {
            text = "ADLEE TIKTOK AUTO"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "Auto Scroll • Auto Claim Shop & LIVE"
            textSize = 14f
            setTextColor(0xFFBDBDC7.toInt())
            setPadding(0, dp(7), 0, dp(24))
        })

        scrollSwitch = Switch(this).apply {
            text = "AUTO SCROLL"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean(KEY_SCROLL, true)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(KEY_SCROLL, checked).apply() }
        }
        page.addView(scrollSwitch, matchWrap())
        page.addView(TextView(this).apply {
            text = "Leret ke video seterusnya secara automatik apabila TikTok berada di skrin."
            textSize = 13f
            setTextColor(0xFFBDBDC7.toInt())
            setPadding(0, dp(3), 0, dp(18))
        })

        claimSwitch = Switch(this).apply {
            text = "AUTO CLAIM SHOP + LIVE"
            textSize = 17f
            setTextColor(0xFFFFFFFF.toInt())
            isChecked = prefs.getBoolean(KEY_CLAIM, false)
            setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(KEY_CLAIM, checked).apply() }
        }
        page.addView(claimSwitch, matchWrap())
        page.addView(TextView(this).apply {
            text = "Cuba tekan butang tuntut/claim yang jelas kelihatan. Tidak akan membuat pembelian atau memintas CAPTCHA."
            textSize = 13f
            setTextColor(0xFFBDBDC7.toInt())
            setPadding(0, dp(3), 0, dp(18))
        })

        intervalText = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 15f
        }
        page.addView(intervalText)
        val seek = SeekBar(this).apply {
            max = 13 // 2 to 15 seconds
            progress = (prefs.getInt(KEY_INTERVAL, 5) - 2).coerceIn(0, 13)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val seconds = progress + 2
                    intervalText.text = "Kelajuan scroll: setiap $seconds saat"
                    if (fromUser) prefs.edit().putInt(KEY_INTERVAL, seconds).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        intervalText.text = "Kelajuan scroll: setiap ${prefs.getInt(KEY_INTERVAL, 5).coerceIn(2, 15)} saat"
        page.addView(seek, matchWrap())

        val accessibilityButton = Button(this).apply {
            text = "1. AKTIFKAN ACCESSIBILITY"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        page.addView(accessibilityButton, buttonParams())

        val openTikTokButton = Button(this).apply {
            text = "2. BUKA TIKTOK"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(TIKTOK_PACKAGE)
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "TikTok biasa tidak dijumpai. Pasang TikTok dahulu.", Toast.LENGTH_LONG).show()
            }
        }
        page.addView(openTikTokButton, buttonParams())

        page.addView(TextView(this).apply {
            text = "CARA GUNA\n1. Hidupkan Auto Scroll / Auto Claim.\n2. Tekan Aktifkan Accessibility dan pilih Adlee TikTok Auto.\n3. Benarkan akses.\n4. Buka TikTok. Pastikan skrin hidup dan TikTok berada di hadapan.\n\nNota: Susun atur TikTok boleh berubah. Fungsi claim hanya berfungsi jika butang boleh dibaca oleh Accessibility. Sesetengah reward mungkin tidak boleh dituntut secara automatik."
            textSize = 13f
            setTextColor(0xFFBDBDC7.toInt())
            setPadding(0, dp(20), 0, 0)
        })

        setContentView(scroller)
    }

    override fun onResume() {
        super.onResume()
        // Settings page is opened separately; service state is controlled by Android Accessibility settings.
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun buttonParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        topMargin = dp(10)
    }

    companion object {
        const val PREFS = "adlee_auto_settings"
        const val KEY_SCROLL = "auto_scroll"
        const val KEY_CLAIM = "auto_claim"
        const val KEY_INTERVAL = "scroll_interval"
        const val TIKTOK_PACKAGE = "com.zhiliaoapp.musically"
    }
}
